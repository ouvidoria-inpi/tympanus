# Changelog
Todas as modificações do componente **br-login-social** estão descritas neste arquivo.

O formato deste arquivo é baseado no [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) e o versionamento deste componente segue o [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2019-07-12
### Changed
- Nome do componente
- Reescrita da documentação

## [0.2.0] - 2019-07-02
### Changed
- Nome da classe de aplicação do estilo
- Aplicação da tipografia dos tokens

## [0.1.1] - 2019-07-01
### Added
- Arquivo minificado

### Changed
- Formato de versionamento

## [0.1.0] - 2019-07-01
### Added
- Documentação inicial
- Estilo básico
