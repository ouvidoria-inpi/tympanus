# Changelog
Todas as modificações do componente **br-divider** estão descritas neste arquivo.

O formato deste arquivo é baseado no [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) e o versionamento deste componente segue o [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2019-07-09
### Changed
- Nome do componente
- Container do conteúdo
- Reescrita da documentação

## [0.1.1] - 2019-07-01
### Added
- Arquivo minificado

### Changed
- Formato de versionamento

## [0.1.0] - 2019-06-28
### Added
- Documentação inicial
- Estilo básico
