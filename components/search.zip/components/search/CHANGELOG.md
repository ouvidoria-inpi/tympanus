# Changelog
Todas as modificações do componente **br-search** estão descritas neste arquivo.

O formato deste arquivo é baseado no [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) e o versionamento deste componente segue o [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] - 2019-09-03
### Fixed
- Alinhamento do botão para o input

## [0.1.0] - 2019-07-08
### Added
- Documentação inicial
- Estilo básico
