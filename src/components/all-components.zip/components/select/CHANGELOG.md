# Changelog
Todas as modificações do componente **br-select** estão descritas neste arquivo.

O formato deste arquivo é baseado no [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) e o versionamento deste componente segue o [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.2] - 2019-09-03
### Changed
- Reescrita do script

### Fixed
- Posição do ícone de select

## [0.1.1] - 2019-08-03
### Fixed
- Espaçamento interno

## [0.1.0] - 2019-07-27
### Added
- Documentação inicial
- Estilo básico
